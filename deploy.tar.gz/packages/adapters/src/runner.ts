import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";

const execAsync = promisify(exec);

export class RunnerAdapter {
    
    // PHASE 3 & 4: CLONING AND REAL EXECUTION
    async cloneRepository(repoUrl: string, token: string, destination: string) {
        // Inject token into URL for authenticated cloning
        const authUrl = repoUrl.replace("https://", `https://x-access-token:${token}@`);
        await execAsync(`git clone ${authUrl} ${destination}`);
    }

    async createBranch(workspace: string, branchName: string) {
        await execAsync(`git checkout -b ${branchName}`, { cwd: workspace });
    }

    async commitAndPush(workspace: string, branchName: string, message: string) {
        await execAsync(`git config user.name "AI Guardian"`, { cwd: workspace });
        await execAsync(`git config user.email "bot@guardian.local"`, { cwd: workspace });
        await execAsync(`git add .`, { cwd: workspace });
        await execAsync(`git commit -m "${message}"`, { cwd: workspace });
        await execAsync(`git push -u origin ${branchName}`, { cwd: workspace });
    }

    async runSecurityScanners(workspace: string) {
        // In a real environment, we run actual OSV-scanner and Gitleaks binaries here.
        // For the hackathon demo on local Windows, we simulate the output so it doesn't crash if tools are missing.
        await new Promise(r => setTimeout(r, 1500));
        return { vulnerabilitiesFound: 1, secretsFound: 0 };
    }

    async applyBobPatch(workspace: string) {
        // Simulate IBM Bob modifying a file to fix the vulnerability
        const readmePath = `${workspace}/README.md`;
        if (fs.existsSync(readmePath)) {
            fs.appendFileSync(readmePath, "\n\n### Security Update\nIBM Bob automatically updated dependencies to fix a critical vulnerability.");
        } else {
            fs.writeFileSync(readmePath, "### Security Update\nIBM Bob fixed vulnerabilities here.");
        }
    }
}
