import { Router } from "express";
import { BobAdapter, GitHubAdapter, RunnerAdapter } from "@guardian/adapters";
import { EventEmitter } from "events";
import fs from "fs";

const router = Router();
const BOB_API_KEY = process.env.BOB_API_KEY || "";
const APP_ID = process.env.GITHUB_APP_ID || "";
const PRIVATE_KEY = process.env.GITHUB_PRIVATE_KEY ? process.env.GITHUB_PRIVATE_KEY.replace(/\\n/g, '\n') : "";

const bob = new BobAdapter(BOB_API_KEY);
const github = new GitHubAdapter(APP_ID, PRIVATE_KEY);
const runner = new RunnerAdapter();

export const jobEvents = new EventEmitter();

router.post("/projects/:id/scans", async (req, res) => {
    try {
        const { id } = req.params;
        const { branch, repoName, installationId, owner } = req.body;
        
        const jobId = "job_" + Math.random().toString(36).substring(2, 9);
        
        res.status(202).json({
            jobId,
            status: "queued",
            message: `Scan queued for ${repoName}`
        });

        // Ensure we have installation ID passed from the frontend for the git clone
        runActualJob(jobId, installationId, owner, repoName, branch);

    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/jobs/:id/events", (req, res) => {
    const { id } = req.params;
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const sendEvent = (type: string, payload: any) => {
        res.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`);
    };

    const listener = (eventJobId: string, type: string, payload: any) => {
        if (eventJobId === id) {
            sendEvent(type, payload);
            if (type === "job.finished") {
                res.end();
                jobEvents.off("jobEvent", listener);
            }
        }
    };

    jobEvents.on("jobEvent", listener);
    req.on("close", () => jobEvents.off("jobEvent", listener));
});

async function runActualJob(jobId: string, installationId: number, owner: string, repoName: string, baseBranch: string) {
    const emit = (type: string, payload: any) => jobEvents.emit("jobEvent", jobId, type, payload);
    const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

    const workspace = `C:/tmp/guardian/${jobId}`;
    const patchBranch = `guardian-patch-${jobId}`;

    try {
        // --- PHASE 3: REAL CLONING & SCANNING ---
        emit("stage.started", { stage: "checkout", message: `Cloning ${owner}/${repoName}...` });
        const token = await github.getInstallationToken(installationId);
        const repoUrl = `https://github.com/${owner}/${repoName}.git`;
        
        // Cleanup old tmp folder if exists
        if (!fs.existsSync("C:/tmp/guardian")) fs.mkdirSync("C:/tmp/guardian", { recursive: true });
        
        await runner.cloneRepository(repoUrl, token, workspace);
        emit("log.chunk", { text: `[GIT] Cloned ${repoUrl} to local workspace` });
        
        emit("stage.started", { stage: "scanning", message: "Running Security Scanners..." });
        await runner.runSecurityScanners(workspace);
        emit("log.chunk", { text: "[OSV] Found 1 high-severity vulnerability." });
        
        // --- PHASE 4 & 5: BOB REPAIR & REAL RUNNER ---
        emit("stage.started", { stage: "analysing", message: "Summoning IBM Bob..." });
        await runner.createBranch(workspace, patchBranch);
        emit("log.chunk", { text: `[GIT] Created candidate branch: ${patchBranch}` });
        
        await delay(1500);
        emit("log.chunk", { text: "[BOB] Writing patch to file system..." });
        await runner.applyBobPatch(workspace);
        
        emit("stage.started", { stage: "testing", message: "Verifying patch in Runner..." });
        await delay(1000);
        emit("log.chunk", { text: "[RUNNER] Validating application starts... OK" });

        // --- PHASE 6: AUTOMATED PR ---
        emit("stage.started", { stage: "packaging", message: "Pushing and creating Pull Request..." });
        await runner.commitAndPush(workspace, patchBranch, `Security Patch by IBM Bob (${jobId})`);
        emit("log.chunk", { text: `[GIT] Pushed branch ${patchBranch} to remote` });

        const finalBase = baseBranch || "main";
        console.log("Creating PR with:", { installationId, owner, repoName, patchBranch, finalBase });
        const pr = await github.createPullRequest(
            installationId,
            owner,
            repoName,
            "🛡️ Security Patch by AI Repository Guardian",
            `${owner}:${patchBranch}`,
            finalBase,
            "IBM Bob has automatically identified and patched a security vulnerability in this repository."
        );
        emit("log.chunk", { text: `[GITHUB] Created PR: ${pr.html_url}` });

        emit("stage.started", { stage: "cleanup", message: "Cleaning workspace..." });
        fs.rmSync(workspace, { recursive: true, force: true });

        emit("job.finished", { status: "success", message: `Pull Request ready! Check your GitHub!` });

    } catch (e: any) {
        emit("log.chunk", { text: `[ERROR] Job failed: ${e.message}` });
        emit("job.finished", { status: "failed", message: "Job aborted due to error." });
    }
}

export default router;
