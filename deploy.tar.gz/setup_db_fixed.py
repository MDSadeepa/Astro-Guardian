import paramiko

HOST = "51.79.165.228"
USER = "ubuntu"
PASS = "endeavoursoftware@A123@2003[EYE]"

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASS, timeout=15)

# Ignore error if user already exists
client.exec_command('sudo -u postgres psql -c "CREATE USER guardian_worker WITH ENCRYPTED PASSWORD \'guardian_hackathon_2026\';"')
# Create DB
stdin, stdout, stderr = client.exec_command('sudo -u postgres psql -c "CREATE DATABASE guardian_db OWNER guardian_worker;"')
print("DB OUT:", stdout.read().decode())
print("DB ERR:", stderr.read().decode())
# Grant privileges
client.exec_command('sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE guardian_db TO guardian_worker;"')

client.close()
