import paramiko
import sys

HOST = "51.79.165.228"
USER = "ubuntu"
PASS = "endeavoursoftware@A123@2003[EYE]"

try:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASS, timeout=15)

    sql_commands = """
    CREATE USER guardian_worker WITH ENCRYPTED PASSWORD 'guardian_hackathon_2026';
    CREATE DATABASE guardian_db OWNER guardian_worker;
    GRANT ALL PRIVILEGES ON DATABASE guardian_db TO guardian_worker;
    """
    
    stdin, stdout, stderr = client.exec_command(f'sudo -u postgres psql -c "{sql_commands}"')
    print("OUT:", stdout.read().decode('utf-8'))
    print("ERR:", stderr.read().decode('utf-8'))
    
    client.close()
except Exception as e:
    print(f"Error: {e}")
